package com.cg.springwithangular.staticDb;

import java.util.ArrayList;
import java.util.List;

import com.cg.springwithangular.beans.Country;

public class CountryDb {

	private static ArrayList<Country> countryList= new ArrayList<Country>();
	
	static {
		countryList.add(new Country("101","India","12322"));
		countryList.add(new Country("102","Indi","12322555"));
		countryList.add(new Country("103","Ind","123552"));
		countryList.add(new Country("104","In","12324"));
		countryList.add(new Country("105","I","12325"));
	}

	public static List<Country> getCountryList() {
		// TODO Auto-generated method stub
		return countryList;
	}
	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList = countryList;
	}
}
