package com.cg.springwithangular.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springwithangular.beans.Country;
import com.cg.springwithangular.dao.CountryDao;

@RestController
@Service
public class CountryServiceImpl implements CountryService{

	@Autowired
	CountryDao dao;
	
	@Override
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return dao.getAllCountries();
	}

	@Override
	public void addCountry(Country country) {
		dao.addCountry(country);
		
	}

	@Override
	public Country deleteCountry(int id) {
		// TODO Auto-generated method stub
		return dao.deleteCountry(id);
	}

	@Override
	public Country searchCountry(int id) {
		
		// TODO Auto-generated method stub
		return dao.searchCountry(id);
	}
	

}
